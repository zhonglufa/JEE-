package com.guihang2.bbs_forum.dao;

import com.guihang2.bbs_forum.pojo.Comment;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CommentDao {
    // 添加评论
    @Insert("INSERT INTO comment (post_id, user_id, content, created_at) " +
            "VALUES (#{postId}, #{userId}, #{content}, #{createdAt})")
    boolean addComment(Comment comment);

    // 删除评论
    @Delete("DELETE FROM comment WHERE comment_id = #{commentId}")
    boolean deleteComment(Integer commentId);

    // 获取某篇文章的所有评论
    @Select("SELECT c.*, u.username as userName " +
            "FROM comment c JOIN user u ON c.user_id = u.user_id " +
            "WHERE c.post_id = #{postId}")
    List<Comment> getCommentsByPostId(Integer postId);
}