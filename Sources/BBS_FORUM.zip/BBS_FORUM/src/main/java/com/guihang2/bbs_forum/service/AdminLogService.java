package com.guihang2.bbs_forum.service;

public interface AdminLogService {
}
