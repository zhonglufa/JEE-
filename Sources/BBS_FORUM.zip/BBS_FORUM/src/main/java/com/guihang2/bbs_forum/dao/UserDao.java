package com.guihang2.bbs_forum.dao;

import com.guihang2.bbs_forum.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserDao {
    //注册用户
    @Select("insert into user (username, password, email, role, created_at) values (#{username}, #{password}, #{email}, #{role}, #{createdAt})")
    void insertUser(User user);
    
    //登录验证
    @Select("select * from user where email= #{email} and password = #{password}")
    User selectUserByUsernameAndPassword(User user);


}