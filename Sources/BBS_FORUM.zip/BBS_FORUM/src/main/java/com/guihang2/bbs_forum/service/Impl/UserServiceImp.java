package com.guihang2.bbs_forum.service.Impl;

import com.guihang2.bbs_forum.dao.UserDao;
import com.guihang2.bbs_forum.pojo.User;
import com.guihang2.bbs_forum.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImp implements UserService {
    @Autowired
    private UserDao userDao;
    //  密码加密
    //private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    public void registerUser(User user) {
        userDao.insertUser(user);
    }

    @Override
    public User loginUser(User user1) {

        User user = userDao.selectUserByUsernameAndPassword(user1);
        return user;
    }
}