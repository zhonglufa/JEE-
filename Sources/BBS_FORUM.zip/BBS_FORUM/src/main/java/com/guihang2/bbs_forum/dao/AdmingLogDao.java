package com.guihang2.bbs_forum.dao;

public interface AdmingLogDao {

}
