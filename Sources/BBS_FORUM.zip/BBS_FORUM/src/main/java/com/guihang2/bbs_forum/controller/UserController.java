package com.guihang2.bbs_forum.controller;

import com.guihang2.bbs_forum.pojo.User;
import com.guihang2.bbs_forum.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("/register")
    public String showRegisterForm() {
        return "register"; // 返回 register.jsp
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") User user) {
        userService.registerUser(user);
        return "redirect:/user/login"; // 注册成功后跳转到登录页面
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login"; // 返回 login.jsp
    }

    @PostMapping("/login")
    public String loginUser(User user1,
                           HttpSession session, Model model) {
        User user = userService.loginUser(user1);
        if (user != null) {
            System.out.println("登录成功");
            session.setAttribute("user", user);
            return "redirect:/index.jsp"; // 登录成功后跳转到首页
        } else {
            model.addAttribute("error", "用户名或密码错误");
            return "login";// 登录失败返回登录页面并显示错误信息
        }
    }
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();// 注销用户
        return "redirect:/index.jsp"; // 注销后跳转到首页
    }
}